run_dir = pwd;
run_deep_auto;
cd(run_dir);
get_auto_encoder_codes;
run;